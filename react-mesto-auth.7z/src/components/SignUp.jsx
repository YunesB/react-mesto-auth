function SignUp(props) {
    return (
        <div>
            SignUp
        </div>
    );
}

export default SignUp;